tar -xf unet_fr.tar.xz
python detect_UNetFR.py
